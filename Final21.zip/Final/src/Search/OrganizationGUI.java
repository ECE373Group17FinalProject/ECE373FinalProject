package Search;

import java.awt.BorderLayout;
import javax.swing.*;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.LayoutManager;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.ArrayList;

import Person.ConvictUser;
import Person.Organization;
import Person.ProbationOfficer;
import Person.Volunteer;
import Thing.Court;
import Thing.Event;
import Thing.Offense;
import Thing.Records;



public class OrganizationGUI extends JFrame {
	private Organization org;
	private JMenuBar menuBar;		//the horizontal container
	private JMenu manageEvents;		//JMenu objects are added to JMenuBar objects as the "tabs"
	private JMenuItem addUserBlacklist;
	private JMenuItem removeUserBlacklist;
	private JMenuItem createEvent;
	private JMenuItem removeEvent;
	private JMenu manageAccountMenu;
	private JMenuItem editBio;
	private JMenuItem logOut;
	private JMenuItem printEvents;
	

	public OrganizationGUI(String windowTitle, Organization organization) {
		super(windowTitle);
		org = organization;

		setSize(1000, 1000);
		
		setLayout(new FlowLayout(FlowLayout.LEFT));
		
		add(new JLabel("<HTML><center>Welcome "+org.getName()+
				"<BR>What would you like to do?"));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		buildGUI();	
		setVisible(true);
	}
	public void buildGUI() 
	{
		menuBar = new JMenuBar();
     	
		
		manageAccountMenu = new JMenu("Manage Account Settings");
		manageEvents = new JMenu("Manage Events");
		
		createEvent = new JMenuItem("Create an Event");
		removeEvent = new JMenuItem("Remove an Event");
		printEvents = new JMenuItem("Print all Events");
		addUserBlacklist = new JMenuItem("Add User to Blacklist");
		removeUserBlacklist = new JMenuItem("Remove User from Blacklist");
		editBio = new JMenuItem ("Edit Organization Mission" );
		logOut = new JMenuItem ("Log Out" );
	
		
		editBio.addActionListener(new MenuListener());	
		createEvent.addActionListener(new MenuListener());
		removeEvent.addActionListener(new MenuListener());
		logOut.addActionListener(new MenuListener());
		addUserBlacklist.addActionListener(new MenuListener());
		removeUserBlacklist.addActionListener(new MenuListener());
		printEvents.addActionListener(new MenuListener());
		
	    
		manageAccountMenu.add(editBio);
		manageAccountMenu.add(addUserBlacklist);
		manageAccountMenu.add(removeUserBlacklist);
		
		manageEvents.add(createEvent);
		manageEvents.add(removeEvent);
		manageEvents.add(printEvents);
		
		
		menuBar.add(manageAccountMenu);
		menuBar.add(manageEvents);
		menuBar.add(logOut);
	    
	
		setJMenuBar(menuBar);
	}
	
	private class MenuListener implements ActionListener
	{
		

		public void actionPerformed(ActionEvent e) //this is the method MenuListener must implement, as it comes from the ActionListener interface.
		{
			JMenuItem source = (JMenuItem)(e.getSource());
			
			if(source.equals(createEvent))
			{
				handleCreateEvent();	
			}
			else if(source.equals(editBio))
			{
				handleEditBio();
			}
			else if(source.equals(removeEvent))
			{
				handleRemoveEvent();
			}
			else if(source.equals(logOut))
			{
				handleLogOut();
			}
			else if(source.equals(addUserBlacklist)) {
				handleAddBlackList();
			}
			else if(source.equals(removeUserBlacklist)) {
				handleRemmoveBlackList();
			}
			else if(source.equals(printEvents)) {
				handlePrintEvents();
			}
	
		}
		private void handlePrintEvents() {
		       JFrame frame = new JFrame("My JFrame Example");

			String results = "";
			for (int i = 0; i < org.getEvents().size(); i++) {
				results = results + "Event #" + Integer.toString(i + 1) + ": " + org.getEvents().get(i).getName() + "\n"; //index and name
				results = results + "Organization: " + org.getEvents().get(i).getOrganization().getName() + "\n";  //organization
				results = results + "Time: " + formatEventTimeSlot(org.getEvents().get(i)) + "\n";    //time slot
				results = results + "Eligible for Community Service? " + determineCSH(org.getEvents().get(i)) + "\n";
				results = results + "Equipment Requested: " + formatEventEquipment(org.getEvents().get(i)) + "\n";
				results = results + "\n" + "\n";
			}
			
		System.out.println(results);
	      // create a JTextArea
	      JTextArea textArea = new JTextArea(15, 40);
	      textArea.setText(results);
	      textArea.setEditable(false);
	      
	      // wrap a scrollpane around it
	      JScrollPane scrollPane = new JScrollPane(textArea);
	      
	      add(scrollPane);
	      
	      JOptionPane.showMessageDialog(frame, scrollPane);

		}
		public String formatEventEquipment(Event e) {
			String formattedEquipment = null;
			for(int i = 0; i < e.getEquipmentsList().size(); i++) {
				formattedEquipment = formattedEquipment + e.getEquipmentsList().get(i);
			}
			return formattedEquipment;
		}
		
		public String determineCSH(Event e) {
			String csh = null;
			if(e.isCshEligible()) {
				csh = "Yes";
			}
			else {
				csh = "No";
			}
			return csh;
		}
		public String formatEventTimeSlot(Event e) {
			String formattedTime = null;
			String beginTime = null;
			String endTime = null;
			int timeSlotSize = 0;
			
			
			if(e.getTimeSlots().size() == 1) {
				formattedTime = (e.convertScheduleCodeDay(e.getTimeSlots().get(0)) + e.convertScheduleCodeTime(e.getTimeSlots().get(0)));
			}
			
			else {
				String[] timeParts = e.convertScheduleCodeTime(e.getTimeSlots().get(0)).split(" ");
				beginTime = timeParts[0]; 
				
				timeSlotSize = e.getTimeSlots().size();
				String[] timeParts1 = e.convertScheduleCodeTime(e.getTimeSlots().get(timeSlotSize - 1)).split(" ");
				endTime = timeParts1[2];

				formattedTime = (e.convertScheduleCodeDay(e.getTimeSlots().get(0)) + beginTime + " - " + endTime);
			}
			
			return formattedTime;
			
		}

		private void handleRemmoveBlackList() {
			// TODO Auto-generated method stub
			String s;
			
			JTextField userName = new JTextField(50);
			
			int result = JOptionPane.showConfirmDialog(null, userName, "Remove user from blacklist.", JOptionPane.OK_CANCEL_OPTION);
			
			if (result == JOptionPane.OK_OPTION) {
				s= userName.getText();
				Volunteer v = new Volunteer();
				boolean userExist = false;
				for(int i = 0; i < org.getSearchEngine().volunteerList.size(); i++) {
					if(s.equals(org.getSearchEngine().volunteerList.get(i).getName())) {
						v = org.getSearchEngine().volunteerList.get(i);
						userExist = true;
					}
					if(userExist == false) {
						//pop up for non existent user
					}
					else {
						if(org.checkBlacklistForUser(v)) org.removeUserFromBlacklist(v);
						else {
							//user is not on blacklist
						}
					}
				}
			}

			
		}

		private void handleAddBlackList() {
			// TODO Auto-generated method stub
			String s;
			
			JTextField userName = new JTextField(200);
			
			int result = JOptionPane.showConfirmDialog(null, userName, "Remove user from blacklist.", JOptionPane.OK_CANCEL_OPTION);
			
			if (result == JOptionPane.OK_OPTION) {
				s= userName.getText();
				Volunteer v = new Volunteer();
				boolean userExist = false;
				for(int i = 0; i < org.getSearchEngine().volunteerList.size(); i++) {
					if(s.equals(org.getSearchEngine().volunteerList.get(i).getName())) {
						v = org.getSearchEngine().volunteerList.get(i);
						userExist = true;
					}
				}
					if(userExist == false) {
						//pop up saying user does not exist
					}
					else {
						org.addUserToBlacklist(v);
						//pop up user added to blacklist
					}
				}
		}

		private void handleRemoveEvent() {
			String s;
			Event e = new Event();
			
			JTextField eventName = new JTextField(50);
			
			int result = JOptionPane.showConfirmDialog(null, eventName, "Remove event.", JOptionPane.OK_CANCEL_OPTION);
			
			if (result == JOptionPane.OK_OPTION) {
				s = eventName.getText();
				for(int i = 0; i < org.getEvents().size(); i++) {
					if(s.equals(org.getEvents().get(i).getName())) {
						org.removeEvent(org.getEvents().get(i));
						//event removed
						return;
					}
				}
				//event not found
			}
		}

		private void handleCreateEvent() {
			String[]   begin  = { "start time","midnight", "1:00am","2:00am","3:00am","4:00am",
											    "5:00am","6:00am ","7:00am","8:00am ","9:00am",
										    "10:00am", "11:00am","noon", "1:00pm", "2:00pm",
											    "3:00pm","4:00pm","5:00pm","6:00pm","7:00pm",  
											    "8:00pm", "9:00pm", "10:00pm","11:00pm","11:59pm"};
			
			String[]   end  = { "end time","midnight", "1:00am","2:00am","3:00am","4:00am",
				    "5:00am","6:00am ","7:00am","8:00am ","9:00am",
			    "10:00am", "11:00am","noon", "1:00pm", "2:00pm",
				    "3:00pm","4:00pm","5:00pm","6:00pm","7:00pm",  
				    "8:00pm", "9:00pm", "10:00pm","11:00pm","11:59pm"};
			
			JComboBox timeBegin = new JComboBox(begin);
			timeBegin.setSelectedIndex(0);
			timeBegin.addActionListener(this);
			JComboBox timeEnd = new JComboBox(end);
			timeEnd.setSelectedIndex(0);
			timeBegin.addActionListener(this);
			
			
			
			JTextField eventName = new JTextField(50);
			JTextField workType = new JTextField(1);
			JTextField xCoord = new JTextField(4);
			JTextField yCoord = new JTextField(4);
			JTextField maxVol = new JTextField(4);
			JRadioButton csh = new JRadioButton("csh",false);
			ButtonGroup days = new ButtonGroup();
			
			JRadioButton
			MonBox = new JRadioButton ("Mon", false),
			TueBox = new JRadioButton ("Tues", false),
			WedBox = new JRadioButton ("Wed", false),
			ThuBox = new JRadioButton ("Thurs", false),
			FriBox = new JRadioButton ("Fri", false),
			SatBox = new JRadioButton ("Sat", false),
			SunBox = new JRadioButton ("Sun", false);
			days.add(MonBox);
			days.add(TueBox);
			days.add(WedBox);
			days.add(ThuBox);
			days.add(FriBox);
			days.add(SatBox);
			days.add(SunBox);
			
			JPanel panel = new JPanel();
			panel.add(MonBox);
			panel.add(TueBox);
			panel.add(WedBox);
			panel.add(ThuBox);
			panel.add(FriBox);
			panel.add(SatBox);
			panel.add(SunBox);
			
			Object [] fields = {
				"Event Name:", eventName,
				"Work Type:",  workType,
				"X coordinates:",xCoord,
				"Y coordinates:",yCoord,
				"Maximum Volunteers:",maxVol,
				"CSH Eligibility:", csh,
				"Days", panel,
				"Duration", timeBegin, timeEnd
			};
			
			int result = JOptionPane.showConfirmDialog(null, fields, "Create Event", JOptionPane.OK_CANCEL_OPTION);
			if (result == JOptionPane.OK_OPTION ) {
				Event e = new Event();
				e.setName(eventName.getText());
				e.setWorkType(Integer.parseInt(workType.getText()));
				e.setLocX(Double.parseDouble(xCoord.getText()));
				e.setLocY(Double.parseDouble(yCoord.getText()));
				e.setMaxUsers(Integer.parseInt(maxVol.getText()));
				e.setCshEligible(csh.isSelected());
				int z = 0;
				if(MonBox.isSelected()) z = 100;
				if(TueBox.isSelected()) z = 200;
				if(WedBox.isSelected()) z = 300;
				if(ThuBox.isSelected()) z = 400;
				if(FriBox.isSelected()) z = 500;
				if(SatBox.isSelected()) z = 600;
				if(SunBox.isSelected()) z = 700;
			
				int i = timeBegin.getSelectedIndex();
				int j = timeEnd.getSelectedIndex();
				System.out.println(i);
				System.out.println(j);
				while(i != j) {
					e.addTimeSlot(z+(i-1));
					i++;
				}
				System.out.println(e.getTimeSlots());
			}
			
		}

		private void handleLogOut() {
			// TODO Auto-generated method stub
			setVisible(false);
		}

		
		private void handleEditBio() {
			String s;
			
			JTextField newBio = new JTextField(50);
			
			int result = JOptionPane.showConfirmDialog(null, newBio, "Edit Mission Statement", JOptionPane.OK_CANCEL_OPTION);
			
			if (result == JOptionPane.OK_OPTION) {
				s= newBio.getText();
				org.setMission(s);
				
			}
		}

			
		private class CheckBoxListener implements ItemListener
		   {
		      public void itemStateChanged(ItemEvent e)
		      {
		        
		 
		      }
		   }
	}
}