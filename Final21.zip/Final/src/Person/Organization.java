package Person;

import java.util.ArrayList;
import Search.SearchEngine;

import Thing.Event;

public class Organization {
	private String name;
	private String username;
	private String password;
	private String mission;
	protected ArrayList<Event> events = new ArrayList<Event>(300);
	protected ArrayList<User> blacklist = new ArrayList<User>(150);
	protected int orgCode;
	private SearchEngine search;

	public Organization (){
		name = "null";
		orgCode = SearchEngine.getOrgListSize();
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getUsername(){
		return username;
	}
	public void setUsername(String n){
		username = n;
	}
	public String getPassword(){
		return password;
	}
	public void setPassword(String n){
		password = n;
	}
	public ArrayList<Event> getEvents() {
		return events;
	}
	public void createEvent(Event event) {
		if(this.name == "null") {
			System.out.println("Organization Incomplete, cannot add or manage events.");
			System.out.println("");
			return;
		}
		this.events.add(event);
		int i = events.size();
	}
	public void removeEvent(Event e) {
		events.remove(e);
	}
	
	public void addUserToBlacklist(User u) {
		blacklist.add(u);
	}
	public void removeUserFromBlacklist(User u) {
		blacklist.remove(u);
	}
	public boolean checkBlacklistForUser (User u) {
		if (blacklist.contains(u)) {
			return true;
		}
		else {
			return false;
		}
	}
	public SearchEngine getSearchEngine() {
		return search;
	}
	public void setSearchEngine(SearchEngine e) {
		search = e;
	}

	public void setMission(String s) {
		// TODO Auto-generated method stub
		mission = s;
	}
	public String getMission() {
		return mission;
	}

}
