package Person;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.LayoutManager;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.ButtonGroup;
import javax.swing.ComboBoxModel;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import Thing.Court;
import Thing.Event;
import Thing.Offense;
import Thing.Records;
import Search.SearchGUI;
import Search.SearchEngine;



public class ProbationOfficerGUI extends JFrame {
	private ProbationOfficer po;
	private SearchEngine search;
	private JMenuBar menuBar;
	private JMenu manageAccount;
	private JMenu editConvicts;
	private JMenuItem addConvict;
	private JMenuItem removeConvict;
	private JMenuItem logOut;
	
	public ProbationOfficerGUI(SearchEngine s, String windowTitle, ProbationOfficer prob) {
		super(windowTitle);
		po = prob; 
		search = s;
		
		setSize(1000, 1000);
		
		setLayout(new FlowLayout(FlowLayout.LEFT));
		
		add(new JLabel("<HTML><center>Welcome "+po.getName()+
				"<BR>What would you like to do?"));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		buildGUI();	
		setVisible(true);
	}

	public void buildGUI() {
		menuBar = new JMenuBar();
		editConvicts = new JMenu("Edit Convicts");
		
		addConvict = new JMenuItem("Add Convict");
		removeConvict = new JMenuItem("Remove Convict");
		logOut = new JMenuItem("Log Out");
		
		manageAccount.add(logOut);
		editConvicts.add(addConvict);
		editConvicts.add(removeConvict);
		
		removeConvict.addActionListener(new MenuListener());
		addConvict.addActionListener(new MenuListener());
		logOut.addActionListener(new MenuListener());

		
		menuBar.add(manageAccount);
		menuBar.add(editConvicts);
		menuBar.add(logOut);

		
		setJMenuBar(menuBar);
	}
	private class MenuListener implements ActionListener
	{
		

		public void actionPerformed(ActionEvent e)
		{
			JMenuItem source = (JMenuItem)(e.getSource());
			
			if(source.equals(addConvict))
			{
				handleAddConvict();	
			}
			else if(source.equals(removeConvict))
			{
				handleRemoveConvict();
			}
			else if(source.equals(logOut))
			{
				setVisible(false);
				//System.exit(0);
			}
	
	
		}
		private void handleAddConvict() {
			JTextField s = new JTextField();
			ConvictUser ss = new ConvictUser();
			int result = JOptionPane.showConfirmDialog(null, s, "Enter Convict Name to Add", JOptionPane.OK_CANCEL_OPTION);
			if(result == JOptionPane.OK_OPTION) {
				for(int i = 0; i < search.convictUserList.size(); i++) {
					if(s.getText().equals(search.convictUserList.get(i).getName())) {
						ss = search.convictUserList.get(i);
						//convict added
						return;
					}
				}
				//convict not found
			}
		}
		private void handleRemoveConvict() {
			JTextField s = new JTextField();
			ConvictUser ss = new ConvictUser();
			int result = JOptionPane.showConfirmDialog(null, s, "Enter Convict Name to Remove", JOptionPane.OK_CANCEL_OPTION);
			if(result == JOptionPane.OK_OPTION) {
				for(int i = 0; i < search.convictUserList.size(); i++) {
					if(s.getText().equals(search.convictUserList.get(i).getName())) {
						po.removeConvict(search.convictUserList.get(i));
						//convict added
						return;
					}
				}
				//convict not found
			}
		}
	}
}	