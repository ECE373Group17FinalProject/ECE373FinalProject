package Search;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.LayoutManager;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.ArrayList;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import Person.ConvictUser;
import Person.Organization;
import Person.ProbationOfficer;
import Person.Volunteer;
import Thing.Court;
import Thing.Event;
import Thing.Offense;
import Thing.Records;



public class VolunteerGUI extends JFrame {
	private Volunteer vol;
	private JMenuBar menuBar;		//the horizontal container
	private JMenuItem searchEvents;		//JMenu objects are added to JMenuBar objects as the "tabs"
	private JMenu manageAccountMenu;
	private JMenu searchMenu;
	private JMenuItem editBio;
	private JMenuItem changeLoc;
	private JMenuItem logOut;
	

	public VolunteerGUI(String windowTitle, Volunteer volunteer) {
		super(windowTitle);
		vol = volunteer;

		setSize(1000, 1000);
		
		setLayout(new FlowLayout(FlowLayout.LEFT));
		
		add(new JLabel("<HTML><center>Welcome "+vol.getName()+
				"<BR>What would you like to do>"));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		buildGUI();	
		setVisible(true);
	}
	public void buildGUI() 
	{
		menuBar = new JMenuBar();
     	
		// Employee Student Menu
		
		manageAccountMenu = new JMenu("Manage Account Settings");
		searchMenu = new JMenu("Search");
		
		searchEvents = new JMenuItem("Search For Event");
		
		editBio = new JMenuItem ("Edit Your Bio" );
		changeLoc = new JMenuItem("Change Your Location");
		logOut = new JMenuItem ("Log Out" );
	
		
		editBio.addActionListener(new MenuListener());	
		changeLoc.addActionListener(new MenuListener());
		logOut.addActionListener(new MenuListener());
		searchEvents.addActionListener(new MenuListener());
		
	    
		manageAccountMenu.add(editBio);
		manageAccountMenu.add(changeLoc);
		
		searchMenu.add(searchEvents);
		
		menuBar.add(manageAccountMenu);
		menuBar.add(searchMenu);
		menuBar.add(logOut);
	    
	
		setJMenuBar(menuBar);
	}
	
	private class MenuListener implements ActionListener
	{
		

		public void actionPerformed(ActionEvent e) //this is the method MenuListener must implement, as it comes from the ActionListener interface.
		{
			JMenuItem source = (JMenuItem)(e.getSource());
			
			if(source.equals(searchEvents))
			{
				handleSearchEvents();	
			}
			else if(source.equals(editBio))
			{
				handleEditBio();
			}
			else if(source.equals(changeLoc))
			{
				handleChangeLoc();
			}
			else if(source.equals(logOut))
			{
				handleLogOut();
			}
	
	
		}

		private void handleLogOut() {
			// TODO Auto-generated method stub

		}

		private void handleChangeLoc() {
			Integer courseNumber = 0;
			JTextField locX = new JTextField(10); 
			JTextField travel = new JTextField(10);
			JTextField locY = new JTextField(10);  
			JPanel changLocationPanel = new JPanel();
			
			changLocationPanel.setLayout(new GridLayout(4,4)); 
			

			changLocationPanel.add(new JLabel("Location X:"));  
			changLocationPanel.add(locX);
			
			
			changLocationPanel.add(new JLabel("Location Y:"));
			changLocationPanel.add(locY);
			

			changLocationPanel.add(new JLabel("Travel Radius:"));
			changLocationPanel.add(travel);
			
			
			int result = JOptionPane.showConfirmDialog(null, changLocationPanel,"Change Location", JOptionPane.OK_CANCEL_OPTION);
			
			if(result == JOptionPane.OK_OPTION) {

				double x = Double.parseDouble(locX.getText());
				double y = Double.parseDouble(locY.getText());
				double t = Double.parseDouble(travel.getText());
				
				
				if( x >= -10 && x <= 10) {
					if( y >= -10 && y <= 10) {
						if( t >= 0 && t <= 30) {
							vol.setLocX(x);
							vol.setLocY(y);
							vol.setTravelRadius(t);
							
						}
						else {
							JOptionPane.showMessageDialog(null, 
									"invalid travel radius", 
									"Invalid Location", 
									JOptionPane.PLAIN_MESSAGE);
							handleChangeLoc();
						}
					}
					else {
						JOptionPane.showMessageDialog(null, 
								"Invalid y", 
								"Invalid Location", 
								JOptionPane.PLAIN_MESSAGE);
						handleChangeLoc();
					}	
					
				}
				else {
					JOptionPane.showMessageDialog(null, 
							"Invalid x", 
							"Invalid Location", 
							JOptionPane.PLAIN_MESSAGE);
					handleChangeLoc();
				}
	
			}
			
		}

		private void handleEditBio() {
			// TODO Auto-generated method stub
			
		}

		private void handleSearchEvents() {
			Integer courseNumber = 0;
			JTextField locX = new JTextField(10); 
			JTextField travel = new JTextField(10);
			JTextField locY = new JTextField(10);  
			JPanel searchEventsPanel = new JPanel();
			JRadioButtonMenuItem cshElgible = new JRadioButtonMenuItem();
			JCheckBox 
		    MonBox = new JCheckBox("Mon"),
		    TueBox = new JCheckBox("Tues"),
		    WedBox = new JCheckBox("Wed"),
		    ThuBox = new JCheckBox("Thurs"),
		    FriBox = new JCheckBox("Fri"),
		    SatBox = new JCheckBox("Sat"),
		    SunBox = new JCheckBox("Sun");
		    

		      // Add an item listener to the check boxes.
			MonBox.addItemListener(new CheckBoxListener());
			TueBox.addItemListener(new CheckBoxListener());
			WedBox.addItemListener(new CheckBoxListener());
			ThuBox.addItemListener(new CheckBoxListener());
			FriBox.addItemListener(new CheckBoxListener());
			SatBox.addItemListener(new CheckBoxListener());
			SunBox.addItemListener(new CheckBoxListener());

		      // Add the label and check boxes to the content pane.

			
			searchEventsPanel.setLayout(new GridLayout(4,4)); 
			
			searchEventsPanel.add(new JLabel("Type of Work (Youth,Cleaning):"));  
			searchEventsPanel.add(new JTextField(10));
			
			searchEventsPanel.add(new JLabel("select times to NOT include:"));  
			searchEventsPanel.add(new JTextField(10));
			
			searchEventsPanel.add(new JLabel("select days to NOT include:"));
			searchEventsPanel.add(MonBox);
			searchEventsPanel.add(TueBox);
			searchEventsPanel.add(WedBox);
			searchEventsPanel.add(ThuBox);
			searchEventsPanel.add(FriBox);
			searchEventsPanel.add(SatBox);
			searchEventsPanel.add(SunBox);
			

			searchEventsPanel.add(new JLabel("Search CSH eligible Events:"));
			searchEventsPanel.add(new JTextField(10));
			
			
			int result = JOptionPane.showConfirmDialog(null, searchEventsPanel,"Search For Event", JOptionPane.OK_CANCEL_OPTION);
			
			
		}
		
		private class CheckBoxListener implements ItemListener
		   {
		      public void itemStateChanged(ItemEvent e)
		      {
		        
		 
		      }
		   }
	}
}