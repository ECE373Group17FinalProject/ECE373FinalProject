package Search;

import java.util.ArrayList;
import java.awt.*;
import java.awt.event.*;
import Person.User;
import Person.ConvictUser;
import Person.Organization;
import Person.ProbationOfficer;
import Person.Volunteer;
import Thing.Court;
import Thing.Event;
import Thing.Offense;
import Thing.Records;




import javax.swing.*;


/* Demo by Lahiru Ariyananda and Peter Hall
   Note :  this is very simple program  used as a  demo on  Serilizing and GUIs. 
   It does not test for faults or errors (  which needs to be implemented) 
 */



public class LoginGUI extends JFrame 
{ 
	//private Employee  emp1;
	private SearchEngine search;
	private JMenuBar menuBar;		//the horizontal container
	private JMenu adminMenu;
	private JMenu adminMenu1; 
	private JMenu adminMenu2; //JMenu objects are added to JMenuBar objects as the "tabs"
	//private ArrayList<Employee> empList;

	// File submenus
    
	// Admin 
	
	//JMenuItem objects are added to JMenu objects as the drop down selections. 
	private JMenuItem adminVolunteerLogin;
	private JMenuItem adminOrganizationLogin;
	private JMenuItem adminConvictLogin;
	private JMenuItem adminPOLogin;
	private JMenuItem adminVolunteerCreate;
	private JMenuItem adminOrganizationCreate;
	private JMenuItem adminConvictCreate;
	private JMenuItem adminPOCreate;

	private JMenuItem adminDropCourse;
	private JMenuItem adminPrintSchedule;
	private JMenuItem adminPrintAllInfo;
	
	public LoginGUI(String windowTitle, SearchEngine s) 
	{
		super(windowTitle);
		
		setSize(1000, 1000);
		
		search = s; 
		
		setLayout(new FlowLayout(FlowLayout.LEFT));
		
		add(new JLabel("<HTML><center>Welcome to the Community Outreach Coordination App" +
				"<BR>Please login or create an account.</center></HTML>"));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		buildGUI();	
		setVisible(true);   // mandatory
	}
	
	
	public void buildGUI() 
	{
		menuBar = new JMenuBar();
     	
		// Employee Student Menu
		
	//	adminMenu = new JMenu("Administrators");
		adminMenu1 = new JMenu("Create Account");
		adminMenu2 = new JMenu("Login");
		
		adminVolunteerLogin = new JMenuItem("Volunteer");
		adminOrganizationLogin = new JMenuItem("Organization");
		adminConvictLogin = new JMenuItem("Convict Volunteer");
		adminPOLogin = new JMenuItem("Probation Officer");
		adminVolunteerCreate = new JMenuItem("Volunteer");
		adminOrganizationCreate = new JMenuItem("Organization");
		adminConvictCreate = new JMenuItem("Convict Volunteer");
		adminPOCreate = new JMenuItem("Probation Officer");
	//	adminDropCourse = new JMenuItem("Drop Course");
	//	adminPrintSchedule = new JMenuItem("Print Schedule");
	//	adminPrintAllInfo = new JMenuItem("Print All Info");

		adminVolunteerLogin.addActionListener(new MenuListener());
		adminOrganizationLogin.addActionListener(new MenuListener());
		adminConvictLogin.addActionListener(new MenuListener());
		adminPOLogin.addActionListener(new MenuListener());
		adminVolunteerCreate.addActionListener(new MenuListener());
		adminOrganizationCreate.addActionListener(new MenuListener());
		adminConvictCreate.addActionListener(new MenuListener());
		adminPOCreate.addActionListener(new MenuListener());
	//	adminAddCourse.addActionListener(new MenuListener());
	//	adminPrintSchedule.addActionListener(new MenuListener());
	//	adminPrintAllInfo.addActionListener(new MenuListener());
		
		adminMenu2.add(adminVolunteerLogin);
		adminMenu2.add(adminOrganizationLogin);
		adminMenu2.add(adminConvictLogin);
		adminMenu2.add(adminPOLogin);
		adminMenu1.add(adminVolunteerCreate);
		adminMenu1.add(adminOrganizationCreate);
		adminMenu1.add(adminConvictCreate);
		adminMenu1.add(adminPOCreate);
	//	adminMenu.add(adminPrintAllInfo);

	    menuBar.add(adminMenu2);
	    menuBar.add(adminMenu1);
	//    menuBar.add(adminMenu);
	
		setJMenuBar(menuBar);
	}
	
	private class MenuListener implements ActionListener
	{
		public void actionPerformed(ActionEvent e) //this is the method MenuListener must implement, as it comes from the ActionListener interface.
		{
			JMenuItem source = (JMenuItem)(e.getSource());
			
			
		/*	if(source.equals(adminSave)) {
				handleAdminSave(search);
			}
			
			else if(source.equals(adminLoad)) {
				handleAdminLoad();
			} */
			
//			else 
			if (source.equals(adminVolunteerLogin)) {
				handleVolunteerLogin();
			}
			if (source.equals(adminOrganizationLogin)) {
				handleOrganizationLogin();
			}
			if (source.equals(adminConvictLogin)) {
				handleConvictLogin();
			}
			else if(source.equals(adminPOLogin)) {
				handlePOLogin();
			}
			else if(source.equals(adminVolunteerCreate))
			{
				handleVolunteerCreate();
			}
			else if(source.equals(adminOrganizationCreate)){
				handleOrganizationCreate();
			}
			else if(source.equals(adminConvictCreate))
			{
				handleConvictCreate();
			}
			else if(source.equals(adminPOCreate)) {
				handlePOCreate();
			}
			
		}
		
	/*	private void handleAdminSave(University u) {
			University.saveData(u);
		}
		
		private void handleAdminLoad() {
			university =  University.loadData();
		} */
		private void handleVolunteerLogin(){
			
			Volunteer volunteer = new Volunteer();
			boolean userExists = false;
			int count = -1;
			JTextField username = new JTextField(7);
		    JTextField password = new JTextField(7);
		    JPanel myPanel = new JPanel();
		    
		    myPanel.setLayout(new GridLayout(8, 8));
		    
		    myPanel.add(new JLabel("Username:"));
		    myPanel.add(username);
		    myPanel.add(Box.createHorizontalStrut(15)); // a spacer
		    myPanel.add(new JLabel("Password:"));
		    myPanel.add(password);
		    
		    int result = JOptionPane.showConfirmDialog(null, myPanel,
		        "Volunteer Login", JOptionPane.OK_CANCEL_OPTION);
		  if (result == JOptionPane.OK_OPTION) {
		      
		    String s = "";
		    // create a JTextArea
		    JTextArea textArea = new JTextArea(15, 40);
		    textArea.setText(s);
		    textArea.setEditable(false);			      
		    JFrame frame = new JFrame(); 
		      
			// find User
			for(int k = 0; k < search.getVolunteerList().size(); k++){
				if(username.getText().equals(search.getVolunteerList().get(k).getUsername())) {
					volunteer = search.getVolunteerList().get(k);
					count = k;
					userExists = true;
					break;
				}
			}
			if (userExists) {
				//verify correct password
				if(password.getText().equals(search.getVolunteerList().get(count).getPassword())) {
					setVisible(false);   // mandatory
					//successful login - take them to their home
					VolunteerGUI newVolunteerGUI = new VolunteerGUI("Volunteer HomePage",volunteer);
					//
					//
					
				}
				else {
					JOptionPane.showMessageDialog(frame,"Incorrect password.", "Login error", JOptionPane.PLAIN_MESSAGE);
				}
			}
			else {
				JOptionPane.showMessageDialog(frame, "Username " + username.getText() + " doesn't exist.", "Login error", JOptionPane.PLAIN_MESSAGE);
				return;
			}
		      
		  }
		}
		private void handleOrganizationLogin(){
			
			Organization organization = new Organization();
			boolean userExists = false;
			int count = -1;
			JTextField username = new JTextField(7);
		    JTextField password = new JTextField(7);
		    JPanel myPanel = new JPanel();
		    
		    myPanel.setLayout(new GridLayout(8, 8));
		    
		    myPanel.add(new JLabel("Username:"));
		    myPanel.add(username);
		    myPanel.add(Box.createHorizontalStrut(15)); // a spacer
		    myPanel.add(new JLabel("Password:"));
		    myPanel.add(password);
		    
		    int result = JOptionPane.showConfirmDialog(null, myPanel,
		        "Organization Login", JOptionPane.OK_CANCEL_OPTION);
		  if (result == JOptionPane.OK_OPTION) {
		      
		    String s = "";
		    // create a JTextArea
		    JTextArea textArea = new JTextArea(15, 40);
		    textArea.setText(s);
		    textArea.setEditable(false);			      
		    JFrame frame = new JFrame(); 
		      
			// find User
			for(int k = 0; k < search.getOrganizationList().size(); k++){
				if(username.getText().equals(search.getOrganizationList().get(k).getUsername())) {
					organization = search.getOrganizationList().get(k);
					count = k;
					userExists = true;
					break;
				}
			}
			if (userExists) {
				//verify correct password
				if(password.getText().equals(search.getOrganizationList().get(count).getPassword())) {
					
					//successful login - take them to their home
					//
					//
					//
					
				}
				else {
					JOptionPane.showMessageDialog(frame,"Incorrect password.", "Login error", JOptionPane.PLAIN_MESSAGE);
				}
			}
			else {
				JOptionPane.showMessageDialog(frame, "Username " + username.getText() + " doesn't exist.", "Login error", JOptionPane.PLAIN_MESSAGE);
				return;
			}
		      
		  }
		}
		private void handleConvictLogin(){
			
			ConvictUser convict = new ConvictUser();
			boolean userExists = false;
			int count = -1;
			JTextField username = new JTextField(7);
		    JTextField password = new JTextField(7);
		    JPanel myPanel = new JPanel();
		    
		    myPanel.setLayout(new GridLayout(8, 8));
		    
		    myPanel.add(new JLabel("Username:"));
		    myPanel.add(username);
		    myPanel.add(Box.createHorizontalStrut(15)); // a spacer
		    myPanel.add(new JLabel("Password:"));
		    myPanel.add(password);
		    
		    int result = JOptionPane.showConfirmDialog(null, myPanel,
		        "Convict User Login", JOptionPane.OK_CANCEL_OPTION);
		  if (result == JOptionPane.OK_OPTION) {
		      
		    String s = "";
		    // create a JTextArea
		    JTextArea textArea = new JTextArea(15, 40);
		    textArea.setText(s);
		    textArea.setEditable(false);			      
		    JFrame frame = new JFrame(); 
		      
			// find User
			for(int k = 0; k < search.getConvictUserList().size(); k++){
				if(username.getText().equals(search.getConvictUserList().get(k).getUsername())) {
					convict = search.getConvictUserList().get(k);
					count = k;
					userExists = true;
					break;
				}
			}
			if (userExists) {
				//verify correct password
				if(password.getText().equals(search.getConvictUserList().get(count).getPassword())) {
					
					//successful login - take them to their home
					//
					//
					//
					
				}
				else {
					JOptionPane.showMessageDialog(frame,"Incorrect password.", "Login error", JOptionPane.PLAIN_MESSAGE);
				}
			}
			else {
				JOptionPane.showMessageDialog(frame, "Username " + username.getText() + " doesn't exist.", "Login error", JOptionPane.PLAIN_MESSAGE);
				return;
			}
		      
		  }
		}
		private void handlePOLogin(){
			
			ProbationOfficer po = new ProbationOfficer();
			boolean userExists = false;
			int count = -1;
			JTextField username = new JTextField(7);
		    JTextField password = new JTextField(7);
		    JPanel myPanel = new JPanel();
		    
		    myPanel.setLayout(new GridLayout(8, 8));
		    
		    myPanel.add(new JLabel("Username:"));
		    myPanel.add(username);
		    myPanel.add(Box.createHorizontalStrut(15)); // a spacer
		    myPanel.add(new JLabel("Password:"));
		    myPanel.add(password);
		    
		    int result = JOptionPane.showConfirmDialog(null, myPanel,
		        "Probation Officer Login", JOptionPane.OK_CANCEL_OPTION);
		  if (result == JOptionPane.OK_OPTION) {
		      
		    String s = "";
		    // create a JTextArea
		    JTextArea textArea = new JTextArea(15, 40);
		    textArea.setText(s);
		    textArea.setEditable(false);			      
		    JFrame frame = new JFrame(); 
		      
			// find User
			for(int k = 0; k < search.getPOList().size(); k++){
				if(username.getText().equals(search.getPOList().get(k).getUsername())) {
					po = search.getPOList().get(k);
					count = k;
					userExists = true;
					break;
				}
			}
			if (userExists) {
				//verify correct password
				if(password.getText().equals(search.getPOList().get(count).getPassword())) {
					
					//successful login - take them to their home
					//
					//
					//
					
				}
				else {
					JOptionPane.showMessageDialog(frame,"Incorrect password.", "Login error", JOptionPane.PLAIN_MESSAGE);
				}
			}
			else {
				JOptionPane.showMessageDialog(frame, "Username " + username.getText() + " doesn't exist.", "Login error", JOptionPane.PLAIN_MESSAGE);
				return;
			}
		      
		  }
		}
		private void handleVolunteerCreate(){
			Volunteer volunteer = new Volunteer();
			boolean userExists = false;
			int count = -1;
			double locX = 11;
			double locY = -11;
			double travRad = 31;
			
			JTextField name = new JTextField(7);
			JTextField username = new JTextField(7);
		    JTextField password = new JTextField(7);
		    JTextField locationX = new JTextField(7);
		    JTextField locationY = new JTextField(7);
		    JTextField travelRadius = new JTextField(7);

		    JPanel myPanel = new JPanel();
		    
		    myPanel.setLayout(new GridLayout(8, 8));
		    
		    myPanel.add(new JLabel("Full name:"));
		    myPanel.add(name);
		    myPanel.add(Box.createHorizontalStrut(15)); // a spacer
		    myPanel.add(new JLabel("Username:"));
		    myPanel.add(username);
		    myPanel.add(Box.createHorizontalStrut(15)); // a spacer
		    myPanel.add(new JLabel("Password:"));
		    myPanel.add(password);
		    myPanel.add(Box.createHorizontalStrut(15)); // a spacer
		    myPanel.add(new JLabel("Location X:"));
		    myPanel.add(locationX);
		    myPanel.add(Box.createHorizontalStrut(15)); // a spacer
		    myPanel.add(new JLabel("Location Y:"));
		    myPanel.add(locationY);
		    myPanel.add(Box.createHorizontalStrut(15)); // a spacer
		    myPanel.add(new JLabel("Travel Radius:"));
		    myPanel.add(travelRadius);
		    
		    int result = JOptionPane.showConfirmDialog(null, myPanel,
		        "Create New Volunteer Account", JOptionPane.OK_CANCEL_OPTION);
		  if (result == JOptionPane.OK_OPTION) {
		      
		    String s = "";
		    // create a JTextArea
		    JTextArea textArea = new JTextArea(15, 40);
		    textArea.setText(s);
		    textArea.setEditable(false);			      
		    JFrame frame = new JFrame(); 
		      
			for(int k = 0; k < search.getVolunteerList().size(); k++){
				if(username.getText().equals(search.getVolunteerList().get(k).getUsername())) {
					userExists = true;
					break;
				}
			}
			// make sure username unique
			if (userExists) {
				JOptionPane.showMessageDialog(frame, "Username " + username.getText() + " already in use.", "Error", JOptionPane.PLAIN_MESSAGE);
				return;
			}
			else { // 
				//make sure location and travelRadius are legit
				locX = Double.parseDouble(locationX.getText());
				locY = Double.parseDouble(locationY.getText());
				travRad = Double.parseDouble(travelRadius.getText());
				
				if(-10 <= locX && locX <= 10) {
					volunteer.setLocX(locX);
				}
				else {
					JOptionPane.showMessageDialog(frame, "Invalid Location X. Must be between -10 and 10.", "Error", JOptionPane.PLAIN_MESSAGE);
					return;
				}
				
				if(-10 <= locX && locX <= 10) {
					volunteer.setLocY(locY);
				}
				else {
					JOptionPane.showMessageDialog(frame, "Invalid Location Y. Must be between -10 and 10.", "Error", JOptionPane.PLAIN_MESSAGE);
					return;
				}
				
				if(0 <= travRad && travRad <= 28.3) {
					volunteer.setTravelRadius(travRad);
				}
				else {
					JOptionPane.showMessageDialog(frame, "Invalid Travel Radius. Must be between 0 and 28.3.", "Error", JOptionPane.PLAIN_MESSAGE);
					return;
				}
				
				volunteer.setName(name.getText());
				volunteer.setUsername(username.getText());
				volunteer.setPassword(password.getText());
				search.volunteerList.add(volunteer);
				JOptionPane.showMessageDialog(frame, "Account " + username.getText() + " was created. You can now login.", "Success!", JOptionPane.PLAIN_MESSAGE);
				return;
			}
		      
		  }
		}
		private void handleOrganizationCreate(){
			Organization organization = new Organization();
			boolean userExists = false;
			int count = -1;

			JTextField name = new JTextField(7);
			JTextField username = new JTextField(7);
		    JTextField password = new JTextField(7);

		    JPanel myPanel = new JPanel();
		    
		    myPanel.setLayout(new GridLayout(8, 8));
		    
		    myPanel.add(new JLabel("Organization Name:"));
		    myPanel.add(name);
		    myPanel.add(Box.createHorizontalStrut(15)); // a spacer
		    myPanel.add(new JLabel("Username:"));
		    myPanel.add(username);
		    myPanel.add(Box.createHorizontalStrut(15)); // a spacer
		    myPanel.add(new JLabel("Password:"));
		    myPanel.add(password);
		    
		    int result = JOptionPane.showConfirmDialog(null, myPanel,
		        "Create New Organization Account", JOptionPane.OK_CANCEL_OPTION);
		  if (result == JOptionPane.OK_OPTION) {
		      
		    String s = "";
		    // create a JTextArea
		    JTextArea textArea = new JTextArea(15, 40);
		    textArea.setText(s);
		    textArea.setEditable(false);			      
		    JFrame frame = new JFrame(); 
		      
			for(int k = 0; k < search.getOrganizationList().size(); k++){
				if(username.getText().equals(search.getOrganizationList().get(k).getUsername())) {
					userExists = true;
					break;
				}
			}
			// make sure username unique
			if (userExists) {
				JOptionPane.showMessageDialog(frame, "Username " + username.getText() + " already in use.", "Error", JOptionPane.PLAIN_MESSAGE);
				return;
			}
			else { // 
				organization.setName(name.getText());
				organization.setUsername(username.getText());
				organization.setPassword(password.getText());
				search.organizationList.add(organization);
				JOptionPane.showMessageDialog(frame, "Account " + username.getText() + " was created. You can now login.", "Success!", JOptionPane.PLAIN_MESSAGE);
				return;
			}
		      
		  }
		}
		private void handleConvictCreate(){
			ConvictUser convict = new ConvictUser();
			boolean userExists = false;
			int count = -1;
			double locX = 11;
			double locY = -11;
			double travRad = 31;
			
			JTextField name = new JTextField(7);
			JTextField username = new JTextField(7);
		    JTextField password = new JTextField(7);
		    JTextField locationX = new JTextField(7);
		    JTextField locationY = new JTextField(7);
		    JTextField travelRadius = new JTextField(7);

		    JPanel myPanel = new JPanel();
		    
		    myPanel.setLayout(new GridLayout(8, 8));
		    
		    myPanel.add(new JLabel("Full name:"));
		    myPanel.add(name);
		    myPanel.add(Box.createHorizontalStrut(15)); // a spacer
		    myPanel.add(new JLabel("Username:"));
		    myPanel.add(username);
		    myPanel.add(Box.createHorizontalStrut(15)); // a spacer
		    myPanel.add(new JLabel("Password:"));
		    myPanel.add(password);
		    myPanel.add(Box.createHorizontalStrut(15)); // a spacer
		    myPanel.add(new JLabel("Location X:"));
		    myPanel.add(locationX);
		    myPanel.add(Box.createHorizontalStrut(15)); // a spacer
		    myPanel.add(new JLabel("Location Y:"));
		    myPanel.add(locationY);
		    myPanel.add(Box.createHorizontalStrut(15)); // a spacer
		    myPanel.add(new JLabel("Travel Radius:"));
		    myPanel.add(travelRadius);
		    
		    int result = JOptionPane.showConfirmDialog(null, myPanel,
		        "Create New Convict Volunteer Account", JOptionPane.OK_CANCEL_OPTION);
		  if (result == JOptionPane.OK_OPTION) {
		      
		    String s = "";
		    // create a JTextArea
		    JTextArea textArea = new JTextArea(15, 40);
		    textArea.setText(s);
		    textArea.setEditable(false);			      
		    JFrame frame = new JFrame(); 
		      
			for(int k = 0; k < search.getConvictUserList().size(); k++){
				if(username.getText().equals(search.getConvictUserList().get(k).getUsername())) {
					userExists = true;
					break;
				}
			}
			// make sure username unique
			if (userExists) {
				JOptionPane.showMessageDialog(frame, "Username " + username.getText() + " already in use.", "Error", JOptionPane.PLAIN_MESSAGE);
				return;
			}
			else { // 
				//make sure location and travelRadius are legit
				locX = Double.parseDouble(locationX.getText());
				locY = Double.parseDouble(locationY.getText());
				travRad = Double.parseDouble(travelRadius.getText());
				
				if(-10 <= locX && locX <= 10) {
					convict.setLocX(locX);
				}
				else {
					JOptionPane.showMessageDialog(frame, "Invalid Location X. Must be between -10 and 10.", "Error", JOptionPane.PLAIN_MESSAGE);
					return;
				}
				
				if(-10 <= locX && locX <= 10) {
					convict.setLocY(locY);
				}
				else {
					JOptionPane.showMessageDialog(frame, "Invalid Location Y. Must be between -10 and 10.", "Error", JOptionPane.PLAIN_MESSAGE);
					return;
				}
				
				if(0 <= travRad && travRad <= 28.3) {
					convict.setTravelRadius(travRad);
				}
				else {
					JOptionPane.showMessageDialog(frame, "Invalid Travel Radius. Must be between 0 and 28.3.", "Error", JOptionPane.PLAIN_MESSAGE);
					return;
				}
				
				convict.setName(name.getText());
				convict.setUsername(username.getText());
				convict.setPassword(password.getText());
				search.convictUserList.add(convict);
				JOptionPane.showMessageDialog(frame, "Account " + username.getText() + " was created. You can now login.", "Success!", JOptionPane.PLAIN_MESSAGE);
				return;
			}
		      
		  }
		}
		private void handlePOCreate(){
			ProbationOfficer po = new ProbationOfficer();
			boolean userExists = false;
			int count = -1;
			double locX = 11;
			double locY = -11;
			double travRad = 31;
			
			JTextField name = new JTextField(7);
			JTextField username = new JTextField(7);
		    JTextField password = new JTextField(7);
		    JTextField locationX = new JTextField(7);
		    JTextField locationY = new JTextField(7);
		    JTextField travelRadius = new JTextField(7);

		    JPanel myPanel = new JPanel();
		    
		    myPanel.setLayout(new GridLayout(8, 8));
		    
		    myPanel.add(new JLabel("Full name:"));
		    myPanel.add(name);
		    myPanel.add(Box.createHorizontalStrut(15)); // a spacer
		    myPanel.add(new JLabel("Username:"));
		    myPanel.add(username);
		    myPanel.add(Box.createHorizontalStrut(15)); // a spacer
		    myPanel.add(new JLabel("Password:"));
		    myPanel.add(password);
		    myPanel.add(Box.createHorizontalStrut(15)); // a spacer
		    myPanel.add(new JLabel("Location X:"));
		    myPanel.add(locationX);
		    myPanel.add(Box.createHorizontalStrut(15)); // a spacer
		    myPanel.add(new JLabel("Location Y:"));
		    myPanel.add(locationY);
		    myPanel.add(Box.createHorizontalStrut(15)); // a spacer
		    myPanel.add(new JLabel("Travel Radius:"));
		    myPanel.add(travelRadius);
		    
		    int result = JOptionPane.showConfirmDialog(null, myPanel,
		        "Create New Probation Officer Account", JOptionPane.OK_CANCEL_OPTION);
		  if (result == JOptionPane.OK_OPTION) {
		      
		    String s = "";
		    // create a JTextArea
		    JTextArea textArea = new JTextArea(15, 40);
		    textArea.setText(s);
		    textArea.setEditable(false);			      
		    JFrame frame = new JFrame(); 
		      
			for(int k = 0; k < search.getPOList().size(); k++){
				if(username.getText().equals(search.getPOList().get(k).getUsername())) {
					userExists = true;
					break;
				}
			}
			// make sure username unique
			if (userExists) {
				JOptionPane.showMessageDialog(frame, "Username " + username.getText() + " already in use.", "Error", JOptionPane.PLAIN_MESSAGE);
				return;
			}
			else { // 
				//make sure location and travelRadius are legit
				locX = Double.parseDouble(locationX.getText());
				locY = Double.parseDouble(locationY.getText());
				travRad = Double.parseDouble(travelRadius.getText());
				
				if(-10 <= locX && locX <= 10) {
					po.setLocX(locX);
				}
				else {
					JOptionPane.showMessageDialog(frame, "Invalid Location X. Must be between -10 and 10.", "Error", JOptionPane.PLAIN_MESSAGE);
					return;
				}
				
				if(-10 <= locX && locX <= 10) {
					po.setLocY(locY);
				}
				else {
					JOptionPane.showMessageDialog(frame, "Invalid Location Y. Must be between -10 and 10.", "Error", JOptionPane.PLAIN_MESSAGE);
					return;
				}
				
				if(0 <= travRad && travRad <= 28.3) {
					po.setTravelRadius(travRad);
				}
				else {
					JOptionPane.showMessageDialog(frame, "Invalid Travel Radius. Must be between 0 and 28.3.", "Error", JOptionPane.PLAIN_MESSAGE);
					return;
				}
				
				po.setName(name.getText());
				po.setUsername(username.getText());
				po.setPassword(password.getText());
				search.probationOfficerList.add(po);
				JOptionPane.showMessageDialog(frame, "Account " + username.getText() + " was created. You can now login.", "Success!", JOptionPane.PLAIN_MESSAGE);
				return;
			}

		  }
	
		}
		private void logOut() {
			setVisible(true); 
		}
	}
	
}
